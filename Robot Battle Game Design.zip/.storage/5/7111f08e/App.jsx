import React, { useState, useEffect } from 'react';
import WalletConnection from './components/WalletConnection';
import GameArena from './components/GameArena';
import SkinSelection from './components/SkinSelection';
import Leaderboard from './components/Leaderboard';
import BackgroundAnimation from './components/BackgroundAnimation';
import './App.css';

function App() {
  const [currentScreen, setCurrentScreen] = useState('home');
  const [walletConnected, setWalletConnected] = useState(false);
  const [selectedSkin, setSelectedSkin] = useState(0);
  const [userAddress, setUserAddress] = useState('');

  useEffect(() => {
    // Check if wallet is already connected
    checkWalletConnection();
  }, []);

  const checkWalletConnection = async () => {
    if (typeof window.ethereum !== 'undefined') {
      try {
        const accounts = await window.ethereum.request({ method: 'eth_accounts' });
        if (accounts.length > 0) {
          setWalletConnected(true);
          setUserAddress(accounts[0]);
        }
      } catch (error) {
        console.error('Error checking wallet connection:', error);
      }
    }
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return (
          <div className="home-screen">
            <div className="hero-section">
              <div className="hero-content">
                <h1 className="game-title">
                  <span className="title-gradient">ROBOT BATTLE</span>
                  <span className="title-subtitle">ARENA</span>
                </h1>
                <p className="game-description">
                  Enter the ultimate 3D combat arena where robots clash in epic battles.
                  Fight, win, and climb the blockchain leaderboard!
                </p>
                
                <div className="menu-buttons">
                  {!walletConnected ? (
                    <WalletConnection 
                      onConnect={(address) => {
                        setWalletConnected(true);
                        setUserAddress(address);
                      }}
                    />
                  ) : (
                    <>
                      <button 
                        className="menu-btn primary"
                        onClick={() => setCurrentScreen('skinSelection')}
                      >
                        START BATTLE
                      </button>
                      <button 
                        className="menu-btn secondary"
                        onClick={() => setCurrentScreen('leaderboard')}
                      >
                        LEADERBOARD
                      </button>
                      <div className="wallet-info">
                        Connected: {userAddress.slice(0, 6)}...{userAddress.slice(-4)}
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        );
      
      case 'skinSelection':
        return (
          <SkinSelection 
            selectedSkin={selectedSkin}
            onSkinSelect={setSelectedSkin}
            onStartBattle={() => setCurrentScreen('game')}
            onBack={() => setCurrentScreen('home')}
          />
        );
      
      case 'game':
        return (
          <GameArena 
            selectedSkin={selectedSkin}
            userAddress={userAddress}
            onGameEnd={() => setCurrentScreen('home')}
            onViewLeaderboard={() => setCurrentScreen('leaderboard')}
          />
        );
      
      case 'leaderboard':
        return (
          <Leaderboard 
            onBack={() => setCurrentScreen('home')}
          />
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="App">
      <BackgroundAnimation />
      <div className="app-content">
        {renderScreen()}
      </div>
    </div>
  );
}

export default App;