import React, { useEffect, useState } from 'react';
import { ethers } from 'ethers';
import './Leaderboard.css';

const CONTRACT_ADDRESS = '0x72d76B5D285a3E6F31D59534e8FBA21742858138';
const CONTRACT_ABI = [
  {
    "inputs": [],
    "name": "getTop10",
    "outputs": [
      {
        "internalType": "address[]",
        "name": "players",
        "type": "address[]"
      },
      {
        "internalType": "uint256[]",
        "name": "scores",
        "type": "uint256[]"
      },
      {
        "internalType": "uint8",
        "name": "count",
        "type": "uint8"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  }
];

const Leaderboard = ({ onBack }) => {
  const [leaderboard, setLeaderboard] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    loadLeaderboard();
  }, []);

  const loadLeaderboard = async () => {
    setLoading(true);
    setError('');
    
    try {
      const provider = new ethers.JsonRpcProvider('https://monad-testnet.rpc.org');
      const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, provider);
      
      const [players, scores, count] = await contract.getTop10();
      
      const leaderboardData = [];
      for (let i = 0; i < count; i++) {
        leaderboardData.push({
          address: players[i],
          score: scores[i].toString(),
          rank: i + 1
        });
      }
      
      setLeaderboard(leaderboardData);
    } catch (error) {
      console.error('Error loading leaderboard:', error);
      setError('Failed to load leaderboard. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const formatAddress = (address) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const getRankIcon = (rank) => {
    switch (rank) {
      case 1: return '🥇';
      case 2: return '🥈';
      case 3: return '🥉';
      default: return `#${rank}`;
    }
  };

  return (
    <div className="leaderboard">
      <div className="leaderboard-header">
        <button className="back-btn" onClick={onBack}>
          ← Back
        </button>
        <h2 className="leaderboard-title">Global Leaderboard</h2>
        <button className="refresh-btn" onClick={loadLeaderboard} disabled={loading}>
          🔄 Refresh
        </button>
      </div>

      <div className="leaderboard-content">
        {loading ? (
          <div className="loading-container">
            <div className="loading-spinner">
              <div className="spinner"></div>
            </div>
            <p>Loading leaderboard from Monad blockchain...</p>
          </div>
        ) : error ? (
          <div className="error-container">
            <div className="error-icon">⚠️</div>
            <p className="error-text">{error}</p>
            <button className="retry-btn" onClick={loadLeaderboard}>
              Try Again
            </button>
          </div>
        ) : leaderboard.length === 0 ? (
          <div className="empty-leaderboard">
            <div className="empty-icon">🏆</div>
            <h3>No Scores Yet</h3>
            <p>Be the first to submit a score to the leaderboard!</p>
          </div>
        ) : (
          <div className="leaderboard-table">
            <div className="table-header">
              <div className="header-rank">Rank</div>
              <div className="header-player">Player</div>
              <div className="header-score">Score</div>
            </div>
            
            <div className="table-body">
              {leaderboard.map((entry, index) => (
                <div 
                  key={entry.address}
                  className={`leaderboard-row ${entry.rank <= 3 ? 'top-three' : ''}`}
                >
                  <div className="rank-cell">
                    <span className="rank-icon">{getRankIcon(entry.rank)}</span>
                  </div>
                  <div className="player-cell">
                    <div className="player-address">{formatAddress(entry.address)}</div>
                  </div>
                  <div className="score-cell">
                    <span className="score-value">{entry.score}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="blockchain-info">
        <div className="chain-badge">
          <span className="chain-icon">⛓️</span>
          <span>Monad Testnet</span>
        </div>
        <div className="contract-info">
          Contract: {formatAddress(CONTRACT_ADDRESS)}
        </div>
      </div>
    </div>
  );
};

export default Leaderboard;