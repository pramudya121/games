import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import './SkinSelection.css';

const ROBOT_SKINS = [
  {
    id: 0,
    name: 'Cyber Warrior',
    color: 0x00ffff,
    description: 'Electric blue combat unit with enhanced shields'
  },
  {
    id: 1,
    name: 'Fire Knight',
    color: 0xff4500,
    description: 'Blazing orange mech with thermal weapons'
  },
  {
    id: 2,
    name: 'Shadow Hunter',
    color: 0x8a2be2,
    description: 'Purple stealth unit with advanced agility'
  },
  {
    id: 3,
    name: 'Plasma Storm',
    color: 0x00ff00,
    description: 'Green energy core with plasma cannons'
  },
  {
    id: 4,
    name: 'Golden Titan',
    color: 0xffd700,
    description: 'Legendary gold-plated heavy assault mech'
  }
];

const SkinSelection = ({ selectedSkin, onSkinSelect, onStartBattle, onBack }) => {
  const mountRef = useRef(null);
  const sceneRef = useRef(null);
  const robotRef = useRef(null);
  const animationIdRef = useRef(null);

  useEffect(() => {
    if (!mountRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 400 / 300, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    
    renderer.setSize(400, 300);
    renderer.setClearColor(0x000000, 0.5);
    mountRef.current.appendChild(renderer.domElement);
    sceneRef.current = scene;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(5, 5, 5);
    scene.add(directionalLight);

    const spotLight = new THREE.SpotLight(ROBOT_SKINS[selectedSkin].color, 0.8);
    spotLight.position.set(0, 10, 5);
    spotLight.target.position.set(0, 0, 0);
    scene.add(spotLight);
    scene.add(spotLight.target);

    // Create robot
    const robotGroup = new THREE.Group();
    
    // Body
    const bodyGeometry = new THREE.BoxGeometry(2, 3, 1);
    const bodyMaterial = new THREE.MeshPhongMaterial({ 
      color: ROBOT_SKINS[selectedSkin].color,
      shininess: 100 
    });
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    body.position.y = 0;
    robotGroup.add(body);

    // Head
    const headGeometry = new THREE.BoxGeometry(1.2, 1.2, 1.2);
    const headMaterial = new THREE.MeshPhongMaterial({ 
      color: ROBOT_SKINS[selectedSkin].color,
      shininess: 100 
    });
    const head = new THREE.Mesh(headGeometry, headMaterial);
    head.position.y = 2.1;
    robotGroup.add(head);

    // Eyes
    const eyeGeometry = new THREE.SphereGeometry(0.1, 8, 8);
    const eyeMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 });
    
    const leftEye = new THREE.Mesh(eyeGeometry, eyeMaterial);
    leftEye.position.set(-0.3, 2.2, 0.6);
    robotGroup.add(leftEye);
    
    const rightEye = new THREE.Mesh(eyeGeometry, eyeMaterial);
    rightEye.position.set(0.3, 2.2, 0.6);
    robotGroup.add(rightEye);

    // Arms
    const armGeometry = new THREE.BoxGeometry(0.6, 2.5, 0.6);
    const armMaterial = new THREE.MeshPhongMaterial({ 
      color: ROBOT_SKINS[selectedSkin].color,
      shininess: 100 
    });
    
    const leftArm = new THREE.Mesh(armGeometry, armMaterial);
    leftArm.position.set(-1.3, 0.2, 0);
    robotGroup.add(leftArm);
    
    const rightArm = new THREE.Mesh(armGeometry, armMaterial);
    rightArm.position.set(1.3, 0.2, 0);
    robotGroup.add(rightArm);

    // Legs
    const legGeometry = new THREE.BoxGeometry(0.8, 2.5, 0.8);
    const legMaterial = new THREE.MeshPhongMaterial({ 
      color: ROBOT_SKINS[selectedSkin].color,
      shininess: 100 
    });
    
    const leftLeg = new THREE.Mesh(legGeometry, legMaterial);
    leftLeg.position.set(-0.5, -2.7, 0);
    robotGroup.add(leftLeg);
    
    const rightLeg = new THREE.Mesh(legGeometry, legMaterial);
    rightLeg.position.set(0.5, -2.7, 0);
    robotGroup.add(rightLeg);

    robotGroup.userData = {
      body,
      head,
      leftArm,
      rightArm,
      leftLeg,
      rightLeg,
      leftEye,
      rightEye
    };

    scene.add(robotGroup);
    robotRef.current = robotGroup;

    camera.position.z = 8;
    camera.position.y = 1;

    // Animation loop
    let time = 0;
    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);
      time += 0.02;

      // Rotate robot
      robotGroup.rotation.y = Math.sin(time * 0.5) * 0.3;
      
      // Breathing animation
      const scale = 1 + Math.sin(time * 2) * 0.02;
      robotGroup.scale.set(scale, scale, scale);

      // Eye glow animation
      const glowIntensity = 0.5 + Math.sin(time * 4) * 0.5;
      leftEye.material.emissive.setRGB(glowIntensity, 0, 0);
      rightEye.material.emissive.setRGB(glowIntensity, 0, 0);

      renderer.render(scene, camera);
    };

    animate();

    // Cleanup
    return () => {
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [selectedSkin]);

  const handleSkinSelect = (skinId) => {
    onSkinSelect(skinId);
  };

  return (
    <div className="skin-selection">
      <div className="skin-header">
        <button className="back-btn" onClick={onBack}>
          ← Back
        </button>
        <h2 className="skin-title">Select Your Robot</h2>
      </div>

      <div className="skin-content">
        <div className="robot-preview">
          <div ref={mountRef} className="robot-viewer" />
          <div className="current-skin-info">
            <h3>{ROBOT_SKINS[selectedSkin].name}</h3>
            <p>{ROBOT_SKINS[selectedSkin].description}</p>
          </div>
        </div>

        <div className="skin-selector">
          <div className="skin-grid">
            {ROBOT_SKINS.map((skin) => (
              <div 
                key={skin.id}
                className={`skin-card ${selectedSkin === skin.id ? 'selected' : ''}`}
                onClick={() => handleSkinSelect(skin.id)}
              >
                <div 
                  className="skin-preview"
                  style={{ backgroundColor: `#${skin.color.toString(16).padStart(6, '0')}` }}
                />
                <div className="skin-info">
                  <h4>{skin.name}</h4>
                  <span className="skin-id">ID: {skin.id}</span>
                </div>
              </div>
            ))}
          </div>
          
          <button 
            className="start-battle-btn"
            onClick={onStartBattle}
          >
            START BATTLE
          </button>
        </div>
      </div>
    </div>
  );
};

export default SkinSelection;