import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { ethers } from 'ethers';
import './GameArena.css';

const CONTRACT_ADDRESS = '0x72d76B5D285a3E6F31D59534e8FBA21742858138';
const CONTRACT_ABI = [
  {
    "inputs": [],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "newOwner",
        "type": "address"
      }
    ],
    "name": "OwnerTransferred",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": true,
        "internalType": "address",
        "name": "player",
        "type": "address"
      },
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "score",
        "type": "uint256"
      },
      {
        "indexed": false,
        "internalType": "uint256",
        "name": "skinId",
        "type": "uint256"
      }
    ],
    "name": "ScoreSubmitted",
    "type": "event"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "score",
        "type": "uint256"
      },
      {
        "internalType": "uint256",
        "name": "skinId",
        "type": "uint256"
      }
    ],
    "name": "submitScore",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "newOwner",
        "type": "address"
      }
    ],
    "name": "transferOwnership",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "name": "bestScore",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "getTop10",
    "outputs": [
      {
        "internalType": "address[]",
        "name": "players",
        "type": "address[]"
      },
      {
        "internalType": "uint256[]",
        "name": "scores",
        "type": "uint256[]"
      },
      {
        "internalType": "uint8",
        "name": "count",
        "type": "uint8"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "MAX_SCORE",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "owner",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "topCount",
    "outputs": [
      {
        "internalType": "uint8",
        "name": "",
        "type": "uint8"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "name": "topPlayers",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "name": "topScores",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  }
];

const ROBOT_COLORS = [0x00ffff, 0xff4500, 0x8a2be2, 0x00ff00, 0xffd700];

const GameArena = ({ selectedSkin, userAddress, onGameEnd, onViewLeaderboard }) => {
  const mountRef = useRef(null);
  const sceneRef = useRef(null);
  const playerRobotRef = useRef(null);
  const enemyRobotRef = useRef(null);
  const animationIdRef = useRef(null);
  
  const [gameState, setGameState] = useState('playing'); // playing, won, lost
  const [playerHP, setPlayerHP] = useState(100);
  const [enemyHP, setEnemyHP] = useState(100);
  const [score, setScore] = useState(0);
  const [isAttacking, setIsAttacking] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [gameMessage, setGameMessage] = useState('');

  // Create robot function
  const createRobot = useCallback((color, position) => {
    const robotGroup = new THREE.Group();
    
    // Body
    const bodyGeometry = new THREE.BoxGeometry(1.5, 2.5, 0.8);
    const bodyMaterial = new THREE.MeshPhongMaterial({ 
      color: color,
      shininess: 100 
    });
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    robotGroup.add(body);

    // Head
    const headGeometry = new THREE.BoxGeometry(1, 1, 1);
    const head = new THREE.Mesh(headGeometry, bodyMaterial);
    head.position.y = 1.75;
    robotGroup.add(head);

    // Eyes
    const eyeGeometry = new THREE.SphereGeometry(0.08, 8, 8);
    const eyeMaterial = new THREE.MeshBasicMaterial({ color: 0xff0000 });
    
    const leftEye = new THREE.Mesh(eyeGeometry, eyeMaterial);
    leftEye.position.set(-0.25, 1.9, 0.5);
    robotGroup.add(leftEye);
    
    const rightEye = new THREE.Mesh(eyeGeometry, eyeMaterial);
    rightEye.position.set(0.25, 1.9, 0.5);
    robotGroup.add(rightEye);

    // Arms
    const armGeometry = new THREE.BoxGeometry(0.5, 2, 0.5);
    
    const leftArm = new THREE.Mesh(armGeometry, bodyMaterial);
    leftArm.position.set(-1, 0.2, 0);
    robotGroup.add(leftArm);
    
    const rightArm = new THREE.Mesh(armGeometry, bodyMaterial);
    rightArm.position.set(1, 0.2, 0);
    robotGroup.add(rightArm);

    // Legs
    const legGeometry = new THREE.BoxGeometry(0.6, 2, 0.6);
    
    const leftLeg = new THREE.Mesh(legGeometry, bodyMaterial);
    leftLeg.position.set(-0.4, -2.25, 0);
    robotGroup.add(leftLeg);
    
    const rightLeg = new THREE.Mesh(legGeometry, bodyMaterial);
    rightLeg.position.set(0.4, -2.25, 0);
    robotGroup.add(rightLeg);

    robotGroup.position.copy(position);
    robotGroup.userData = {
      body, head, leftArm, rightArm, leftLeg, rightLeg, leftEye, rightEye,
      originalPosition: position.clone()
    };

    return robotGroup;
  }, []);

  useEffect(() => {
    if (!mountRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x001122, 0.8);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    mountRef.current.appendChild(renderer.domElement);
    sceneRef.current = scene;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.4);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(10, 10, 5);
    directionalLight.castShadow = true;
    scene.add(directionalLight);

    // Arena floor
    const floorGeometry = new THREE.PlaneGeometry(20, 20);
    const floorMaterial = new THREE.MeshPhongMaterial({ 
      color: 0x333333,
      transparent: true,
      opacity: 0.8 
    });
    const floor = new THREE.Mesh(floorGeometry, floorMaterial);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -3;
    floor.receiveShadow = true;
    scene.add(floor);

    // Create robots
    const playerRobot = createRobot(ROBOT_COLORS[selectedSkin], new THREE.Vector3(-4, 0, 0));
    const enemyRobot = createRobot(0x666666, new THREE.Vector3(4, 0, 0));
    
    playerRobot.castShadow = true;
    enemyRobot.castShadow = true;
    
    scene.add(playerRobot);
    scene.add(enemyRobot);
    
    playerRobotRef.current = playerRobot;
    enemyRobotRef.current = enemyRobot;

    // Camera position
    camera.position.set(0, 3, 10);
    camera.lookAt(0, 0, 0);

    // Animation loop
    let time = 0;
    let enemyAttackCooldown = 0;
    
    const animate = () => {
      animationIdRef.current = requestAnimationFrame(animate);
      time += 0.02;

      // Robots face each other
      playerRobot.lookAt(enemyRobot.position);
      enemyRobot.lookAt(playerRobot.position);

      // Idle animations
      if (!isAttacking) {
        playerRobot.position.y = Math.sin(time * 2) * 0.1;
        enemyRobot.position.y = Math.sin(time * 2 + Math.PI) * 0.1;
      }

      // Enemy AI attack
      enemyAttackCooldown -= 0.02;
      if (enemyAttackCooldown <= 0 && gameState === 'playing') {
        enemyAttackCooldown = 2 + Math.random() * 2; // Attack every 2-4 seconds
        
        // Enemy attack animation
        enemyRobot.userData.rightArm.rotation.z = -Math.PI/2;
        setTimeout(() => {
          if (enemyRobotRef.current) {
            enemyRobot.userData.rightArm.rotation.z = 0;
          }
        }, 300);

        // Damage player
        setPlayerHP(prev => {
          const newHP = Math.max(0, prev - (10 + Math.random() * 10));
          if (newHP <= 0) {
            setGameState('lost');
            setGameMessage('DEFEAT! Your robot has been destroyed!');
          }
          return newHP;
        });
      }

      renderer.render(scene, camera);
    };

    animate();

    // Handle resize
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current);
      }
      window.removeEventListener('resize', handleResize);
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [selectedSkin, createRobot, isAttacking, gameState]);

  // Attack function
  const attack = useCallback(() => {
    if (isAttacking || gameState !== 'playing') return;

    setIsAttacking(true);
    
    // Player attack animation
    const playerRobot = playerRobotRef.current;
    if (playerRobot) {
      playerRobot.userData.rightArm.rotation.z = Math.PI/2;
      setTimeout(() => {
        if (playerRobotRef.current) {
          playerRobot.userData.rightArm.rotation.z = 0;
        }
      }, 300);
    }

    // Damage enemy
    const damage = 15 + Math.random() * 10;
    setEnemyHP(prev => {
      const newHP = Math.max(0, prev - damage);
      if (newHP <= 0) {
        const finalScore = 1000 + Math.floor(playerHP * 10);
        setScore(finalScore);
        setGameState('won');
        setGameMessage(`VICTORY! Your final score: ${finalScore}`);
      }
      return newHP;
    });

    setScore(prev => prev + Math.floor(damage));
    
    setTimeout(() => setIsAttacking(false), 500);
  }, [isAttacking, gameState, playerHP]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyPress = (event) => {
      if (event.code === 'Space') {
        event.preventDefault();
        attack();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [attack]);

  // Submit score to blockchain
  const submitScore = async () => {
    if (!userAddress || isSubmitting) return;

    setIsSubmitting(true);
    try {
      const provider = new ethers.BrowserProvider(window.ethereum);
      const signer = await provider.getSigner();
      const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);

      const tx = await contract.submitScore(score, selectedSkin);
      await tx.wait();
      
      setGameMessage('Score submitted successfully to Monad blockchain!');
    } catch (error) {
      console.error('Error submitting score:', error);
      setGameMessage('Failed to submit score. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="game-arena">
      <div ref={mountRef} className="game-canvas" />
      
      {/* Game UI */}
      <div className="game-ui">
        {/* HP Bars */}
        <div className="hp-container">
          <div className="player-hp">
            <div className="hp-label">PLAYER HP</div>
            <div className="hp-bar">
              <div 
                className="hp-fill player" 
                style={{ width: `${playerHP}%` }}
              />
            </div>
            <div className="hp-text">{playerHP}/100</div>
          </div>
          
          <div className="enemy-hp">
            <div className="hp-label">ENEMY HP</div>
            <div className="hp-bar">
              <div 
                className="hp-fill enemy" 
                style={{ width: `${enemyHP}%` }}
              />
            </div>
            <div className="hp-text">{enemyHP}/100</div>
          </div>
        </div>

        {/* Score */}
        <div className="score-display">
          SCORE: {score}
        </div>

        {/* Controls */}
        {gameState === 'playing' && (
          <div className="controls">
            <div className="control-info">Press SPACEBAR to attack!</div>
            <button 
              className="attack-btn" 
              onClick={attack}
              disabled={isAttacking}
            >
              {isAttacking ? 'ATTACKING...' : 'ATTACK'}
            </button>
          </div>
        )}

        {/* Game Over Screen */}
        {gameState !== 'playing' && (
          <div className="game-over">
            <div className="game-message">{gameMessage}</div>
            
            {gameState === 'won' && (
              <div className="victory-actions">
                <button 
                  className="submit-score-btn"
                  onClick={submitScore}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? 'SUBMITTING...' : 'SUBMIT SCORE TO BLOCKCHAIN'}
                </button>
                <button 
                  className="view-leaderboard-btn"
                  onClick={onViewLeaderboard}
                >
                  VIEW LEADERBOARD
                </button>
              </div>
            )}
            
            <div className="game-actions">
              <button 
                className="play-again-btn"
                onClick={() => window.location.reload()}
              >
                PLAY AGAIN
              </button>
              <button 
                className="back-menu-btn"
                onClick={onGameEnd}
              >
                BACK TO MENU
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default GameArena;