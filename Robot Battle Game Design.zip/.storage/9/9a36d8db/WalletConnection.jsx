import React, { useState } from 'react';
import './WalletConnection.css';

const MONAD_TESTNET_CONFIG = {
  chainId: '0x279F', // 10143 in hex
  chainName: 'Monad Testnet',
  nativeCurrency: {
    name: 'MON',
    symbol: 'MON',
    decimals: 18,
  },
  rpcUrls: ['https://monad-testnet.rpc.org'],
  blockExplorerUrls: ['https://testnet.monadexplorer.com'],
};

const WalletConnection = ({ onConnect }) => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState('');

  const connectWallet = async () => {
    if (typeof window.ethereum === 'undefined') {
      setError('MetaMask is not installed. Please install MetaMask to continue.');
      return;
    }

    setIsConnecting(true);
    setError('');

    try {
      // Request account access
      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts',
      });

      if (accounts.length === 0) {
        throw new Error('No accounts found');
      }

      // Check if we're on the correct network
      const chainId = await window.ethereum.request({ method: 'eth_chainId' });
      
      if (chainId !== MONAD_TESTNET_CONFIG.chainId) {
        try {
          // Try to switch to Monad testnet
          await window.ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId: MONAD_TESTNET_CONFIG.chainId }],
          });
        } catch (switchError) {
          // If the chain hasn't been added to MetaMask, add it
          if (switchError.code === 4902) {
            await window.ethereum.request({
              method: 'wallet_addEthereumChain',
              params: [MONAD_TESTNET_CONFIG],
            });
          } else {
            throw switchError;
          }
        }
      }

      onConnect(accounts[0]);
    } catch (error) {
      console.error('Error connecting wallet:', error);
      setError(error.message || 'Failed to connect wallet');
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <div className="wallet-connection">
      <button 
        className="connect-wallet-btn"
        onClick={connectWallet}
        disabled={isConnecting}
      >
        {isConnecting ? (
          <div className="loading-spinner">
            <div className="spinner"></div>
            <span>Connecting...</span>
          </div>
        ) : (
          <>
            <div className="wallet-icon">🔗</div>
            <span>Connect Wallet</span>
          </>
        )}
      </button>
      
      {error && <div className="error-message">{error}</div>}
      
      <div className="network-info">
        <p>🔗 Monad Testnet Required</p>
        <p>Chain ID: 10143</p>
      </div>
    </div>
  );
};

export default WalletConnection;